---
title: {{ replace .TranslationBaseName "-" " " | title }}
date: {{ .Date }}
lastmod: {{ .Date }}
cover:
draft: true
link: //enter the link to which this card will redirect to
weight:
description:
---
